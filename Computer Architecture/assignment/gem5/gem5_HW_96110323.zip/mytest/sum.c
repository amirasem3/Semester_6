#include<stdio.h>


int main(){

int a = 14 ; 
int b  = 17;

int z = a+b;
printf("The sum is  : %d \n" , z);


return 0 ; 
}
